package com.jama.pitch432;

import android.app.Application;
import android.media.audiofx.AudioEffect;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Process;
import android.os.SystemClock;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

public class App extends Application {
    static final UUID TYPE = UUID.fromString("3f2a6b1c-84d7-4e0a-9c35-71b8d0e24a60");
    static final UUID IMPL = UUID.fromString("7c1d9e52-30ab-4f68-b2e4-5a96c0d83f17");

    private static final String DIR = "/data/pitch432/";

    private AudioEffect fx;
    private Handler h;
    private int fails;

    private boolean logOn;
    private long maxBytes = 1024L * 1024L;
    private long cfgNext;
    private String last = "";

    @Override
    public void onCreate() {
        super.onCreate();
        loadCfg();
        String hid = unlockHidden();
        log("app started" + (hid == null ? "" : ", hidden api exemption failed: " + hid));
        HandlerThread t = new HandlerThread("pitch432");
        t.start();
        h = new Handler(t.getLooper());
        h.post(new Runnable() {
            @Override
            public void run() {
                loadCfg();
                check();
                h.postDelayed(this, fails > 0 ? 15000 : 5000);
            }
        });
    }

    private void check() {
        boolean ok = false;
        String why = "no effect object";
        if (fx != null) {
            try {
                boolean ctl = fx.hasControl();
                boolean en = fx.getEnabled();
                ok = ctl && en;
                why = "hasControl=" + ctl + " enabled=" + en;
            } catch (Throwable t) {
                why = "check threw " + describe(t);
            }
        }
        if (ok) {
            fails = 0;
            st("OK effect active (hasControl + enabled)");
            return;
        }
        st("effect not active: " + why + " -> re-attaching");
        if (fx != null) {
            try {
                fx.release();
            } catch (Throwable ignored) {
            }
            fx = null;
        }
        try {
            Constructor<AudioEffect> c = AudioEffect.class.getDeclaredConstructor(
                    UUID.class, UUID.class, int.class, int.class);
            c.setAccessible(true);
            AudioEffect e = c.newInstance(TYPE, IMPL, 0, 0);
            e.setEnabled(true);
            fx = e;
            fails = 0;
            st("attach ok, enabled=" + e.getEnabled() + " hasControl=" + e.hasControl());
        } catch (Throwable t) {
            fails++;
            st("attach failed (#" + fails + "): " + describe(t));
        }
    }

    private static String describe(Throwable t) {
        Throwable c = t;
        if (t instanceof InvocationTargetException && ((InvocationTargetException) t).getTargetException() != null) {
            c = ((InvocationTargetException) t).getTargetException();
        }
        String s = c.getClass().getName() + ": " + c.getMessage();
        if (c.getCause() != null) s += " / cause " + c.getCause();
        return s;
    }

    private static String unlockHidden() {
        try {
            Method forName = Class.class.getDeclaredMethod("forName", String.class);
            Method getDeclaredMethod = Class.class.getDeclaredMethod(
                    "getDeclaredMethod", String.class, Class[].class);
            Class<?> vmRuntime = (Class<?>) forName.invoke(null, "dalvik.system.VMRuntime");
            Method getRuntime = (Method) getDeclaredMethod.invoke(vmRuntime, "getRuntime", null);
            Method setEx = (Method) getDeclaredMethod.invoke(
                    vmRuntime, "setHiddenApiExemptions", new Class[]{String[].class});
            Object rt = getRuntime.invoke(null);
            setEx.invoke(rt, new Object[]{new String[]{"L"}});
            return null;
        } catch (Throwable t) {
            return describe(t);
        }
    }

    // ---- file log (config: /data/pitch432/config.txt) ----
    private void loadCfg() {
        long now = SystemClock.elapsedRealtime();
        if (now < cfgNext) return;
        cfgNext = now + 3000;
        try (BufferedReader r = new BufferedReader(new FileReader(DIR + "config.txt"))) {
            String l;
            while ((l = r.readLine()) != null) {
                l = l.trim();
                if (l.isEmpty() || l.startsWith("#")) continue;
                int i = l.indexOf('=');
                if (i < 0) continue;
                String k = l.substring(0, i).trim();
                String v = l.substring(i + 1).trim();
                if (k.equals("log")) {
                    logOn = v.startsWith("1");
                } else if (k.equals("max_log_kb")) {
                    try {
                        long x = Long.parseLong(v);
                        if (x >= 16 && x <= 65536) maxBytes = x * 1024L;
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private void st(String s) {
        if (!s.equals(last) && logOn) {
            last = s;
            log(s);
        }
    }

    private void log(String s) {
        if (!logOn) return;
        try {
            String line = new SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US).format(new Date())
                    + " [" + Process.myPid() + " app] " + s + "\n";
            byte[] b = line.getBytes("UTF-8");
            File f = new File(DIR + "pitch432.log");
            if (f.length() + b.length > maxBytes) {
                try (FileOutputStream o = new FileOutputStream(f, false)) {
                    o.write("--- log cleared (max size reached) ---\n".getBytes("UTF-8"));
                }
            }
            try (FileOutputStream o = new FileOutputStream(f, true)) {
                o.write(b);
            }
        } catch (Throwable ignored) {
        }
    }
}
