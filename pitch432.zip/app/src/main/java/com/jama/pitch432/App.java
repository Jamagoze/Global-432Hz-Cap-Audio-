package com.jama.pitch432;

import android.app.Application;
import android.media.audiofx.AudioEffect;
import android.os.Handler;
import android.os.HandlerThread;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.UUID;

public class App extends Application {
    static final UUID TYPE = UUID.fromString("3f2a6b1c-84d7-4e0a-9c35-71b8d0e24a60");
    static final UUID IMPL = UUID.fromString("7c1d9e52-30ab-4f68-b2e4-5a96c0d83f17");

    private AudioEffect fx;
    private Handler h;
    private int fails;

    @Override
    public void onCreate() {
        super.onCreate();
        unlockHidden();
        HandlerThread t = new HandlerThread("pitch432");
        t.start();
        h = new Handler(t.getLooper());
        h.post(new Runnable() {
            @Override
            public void run() {
                check();
                h.postDelayed(this, fails > 0 ? 15000 : 5000);
            }
        });
    }

    private void check() {
        boolean ok = false;
        if (fx != null) {
            try {
                ok = fx.hasControl() && fx.getEnabled();
            } catch (Throwable ignored) {
            }
        }
        if (ok) {
            fails = 0;
            return;
        }
        if (fx != null) {
            try {
                fx.release();
            } catch (Throwable ignored) {
            }
            fx = null;
        }
        try {
            Constructor<AudioEffect> c = AudioEffect.class.getDeclaredConstructor(
                    UUID.class, UUID.class, int.class, int.class);
            c.setAccessible(true);
            AudioEffect e = c.newInstance(TYPE, IMPL, 0, 0);
            e.setEnabled(true);
            fx = e;
            fails = 0;
        } catch (Throwable t) {
            fails++;
        }
    }

    private static void unlockHidden() {
        try {
            Method forName = Class.class.getDeclaredMethod("forName", String.class);
            Method getDeclaredMethod = Class.class.getDeclaredMethod(
                    "getDeclaredMethod", String.class, Class[].class);
            Class<?> vmRuntime = (Class<?>) forName.invoke(null, "dalvik.system.VMRuntime");
            Method getRuntime = (Method) getDeclaredMethod.invoke(vmRuntime, "getRuntime", null);
            Method setEx = (Method) getDeclaredMethod.invoke(
                    vmRuntime, "setHiddenApiExemptions", new Class[]{String[].class});
            Object rt = getRuntime.invoke(null);
            setEx.invoke(rt, new Object[]{new String[]{"L"}});
        } catch (Throwable ignored) {
        }
    }
}
