// Pitch432: audio effect library (effect API 2.0) shifting pitch by 432/440 using SoundTouch.
#include <errno.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <vector>
#include "SoundTouch.h"

#define EFFECT_STRING_LEN_MAX 64

typedef struct effect_uuid_s {
    uint32_t timeLow;
    uint16_t timeMid;
    uint16_t timeHiAndVersion;
    uint16_t clockSeq;
    uint8_t node[6];
} effect_uuid_t;

typedef struct effect_descriptor_s {
    effect_uuid_t type;
    effect_uuid_t uuid;
    uint32_t apiVersion;
    uint32_t flags;
    uint16_t cpuLoad;
    uint16_t memoryUsage;
    char name[EFFECT_STRING_LEN_MAX];
    char implementor[EFFECT_STRING_LEN_MAX];
} effect_descriptor_t;

typedef struct audio_buffer_s {
    size_t frameCount;
    union {
        void* raw;
        float* f32;
        int32_t* s32;
        int16_t* s16;
        uint8_t* u8;
    };
} audio_buffer_t;

typedef int32_t (*buffer_function_t)(void* cookie, audio_buffer_t* buffer);
typedef struct buffer_provider_s {
    buffer_function_t getBuffer;
    buffer_function_t releaseBuffer;
    void* cookie;
} buffer_provider_t;

typedef struct buffer_config_s {
    audio_buffer_t buffer;
    uint32_t samplingRate;
    uint32_t channels;
    buffer_provider_t bufferProvider;
    uint8_t format;
    uint8_t accessMode;
    uint16_t mask;
} buffer_config_t;

typedef struct effect_config_s {
    buffer_config_t inputCfg;
    buffer_config_t outputCfg;
} effect_config_t;

struct effect_interface_s;
typedef struct effect_interface_s** effect_handle_t;

struct effect_interface_s {
    int32_t (*process)(effect_handle_t self, audio_buffer_t* in, audio_buffer_t* out);
    int32_t (*command)(effect_handle_t self, uint32_t cmdCode, uint32_t cmdSize, void* pCmdData,
                       uint32_t* replySize, void* pReplyData);
    int32_t (*get_descriptor)(effect_handle_t self, effect_descriptor_t* pDescriptor);
    int32_t (*process_reverse)(effect_handle_t self, audio_buffer_t* in, audio_buffer_t* out);
};

typedef struct audio_effect_library_s {
    uint32_t tag;
    uint32_t version;
    const char* name;
    const char* implementor;
    int32_t (*create_effect)(const effect_uuid_t* uuid, int32_t sessionId, int32_t ioId,
                             effect_handle_t* pHandle);
    int32_t (*release_effect)(effect_handle_t handle);
    int32_t (*get_descriptor)(const effect_uuid_t* uuid, effect_descriptor_t* pDescriptor);
} audio_effect_library_t;

enum {
    CMD_INIT = 0, CMD_SET_CONFIG = 1, CMD_RESET = 2, CMD_ENABLE = 3, CMD_DISABLE = 4,
    CMD_SET_DEVICE = 9, CMD_SET_VOLUME = 10, CMD_SET_AUDIO_MODE = 11, CMD_SET_CONFIG_REVERSE = 12,
    CMD_SET_INPUT_DEVICE = 13, CMD_GET_CONFIG = 14, CMD_GET_CONFIG_REVERSE = 15,
    CMD_SET_AUDIO_SOURCE = 19
};
enum { FMT_PCM16 = 1, FMT_FLOAT = 5 };
enum { ACCESS_WRITE = 0, ACCESS_ACCUMULATE = 1 };

static const uint32_t LIB_TAG = (('A' << 24) | ('E' << 16) | ('L' << 8) | 'T');
static const uint32_t API_VERSION = (2u << 16);      // effect control API (descriptor)
static const uint32_t LIB_VERSION = (3u << 16);      // effect library API
static const uint32_t FX_FLAGS = (0u << 0) | (2u << 3);  // insert, last

static const effect_uuid_t FX_TYPE = {0x3f2a6b1c, 0x84d7, 0x4e0a, 0x9c35,
                                      {0x71, 0xb8, 0xd0, 0xe2, 0x4a, 0x60}};
static const effect_uuid_t FX_UUID = {0x7c1d9e52, 0x30ab, 0x4f68, 0xb2e4,
                                      {0x5a, 0x96, 0xc0, 0xd8, 0x3f, 0x17}};

static const double PITCH_RATIO = 432.0 / 440.0;

static void fillDescriptor(effect_descriptor_t* d) {
    memset(d, 0, sizeof(*d));
    d->type = FX_TYPE;
    d->uuid = FX_UUID;
    d->apiVersion = API_VERSION;
    d->flags = FX_FLAGS;
    d->cpuLoad = 80;
    d->memoryUsage = 64;
    strncpy(d->name, "Pitch432", EFFECT_STRING_LEN_MAX - 1);
    strncpy(d->implementor, "Jamagoze", EFFECT_STRING_LEN_MAX - 1);
}

struct Ctx {
    effect_interface_s* itfe;  // must be first
    effect_config_t cfg;
    soundtouch::SoundTouch* st;
    bool configured, enabled, primed;
    uint32_t ch, fmt, sr;
    size_t prime;
    std::vector<float> tin, tout, rbuf, q;
};

static void resetCtx(Ctx* c) {
    c->st->clear();
    c->q.clear();
    c->primed = false;
}

static int32_t setConfig(Ctx* c, const effect_config_t* cfg) {
    if (cfg->inputCfg.samplingRate != cfg->outputCfg.samplingRate) return -EINVAL;
    if (cfg->inputCfg.channels != cfg->outputCfg.channels) return -EINVAL;
    if (cfg->inputCfg.format != cfg->outputCfg.format) return -EINVAL;
    if (cfg->inputCfg.format != FMT_PCM16 && cfg->inputCfg.format != FMT_FLOAT) return -EINVAL;
    if (cfg->outputCfg.accessMode != ACCESS_WRITE && cfg->outputCfg.accessMode != ACCESS_ACCUMULATE)
        return -EINVAL;
    uint32_t ch = __builtin_popcount(cfg->inputCfg.channels & 0x3FFFFFFFu);
    if (ch < 1 || ch > 16) return -EINVAL;
    if (cfg->inputCfg.samplingRate < 8000 || cfg->inputCfg.samplingRate > 384000) return -EINVAL;
    c->cfg = *cfg;
    c->ch = ch;
    c->fmt = cfg->inputCfg.format;
    c->sr = cfg->inputCfg.samplingRate;
    c->prime = (size_t)(c->sr * 0.04);
    c->st->setSampleRate(c->sr);
    c->st->setChannels(ch);
    c->st->setPitch(PITCH_RATIO);
    c->st->setSetting(SETTING_USE_QUICKSEEK, 1);
    c->st->setSetting(SETTING_SEQUENCE_MS, 20);
    c->st->setSetting(SETTING_SEEKWINDOW_MS, 10);
    c->st->setSetting(SETTING_OVERLAP_MS, 6);
    c->rbuf.assign((size_t)ch * 1024, 0.f);
    c->configured = true;
    resetCtx(c);
    return 0;
}

static int32_t fx_process(effect_handle_t self, audio_buffer_t* in, audio_buffer_t* out) {
    Ctx* c = (Ctx*)self;
    if (!c || !in || !out || !in->raw || !out->raw || in->frameCount != out->frameCount)
        return -EINVAL;
    if (!c->configured) return -EINVAL;
    const size_t n = in->frameCount, ch = c->ch, ns = n * ch;
    const bool acc = c->cfg.outputCfg.accessMode == ACCESS_ACCUMULATE;
    c->tin.resize(ns);
    c->tout.resize(ns);
    float* tin = c->tin.data();
    float* tout = c->tout.data();

    if (c->fmt == FMT_FLOAT) {
        memcpy(tin, in->f32, ns * sizeof(float));
    } else {
        for (size_t i = 0; i < ns; i++) tin[i] = in->s16[i] * (1.0f / 32768.0f);
    }

    if (!c->enabled) {
        memcpy(tout, tin, ns * sizeof(float));
    } else {
        c->st->putSamples(tin, (unsigned)n);
        unsigned got;
        while ((got = c->st->receiveSamples(c->rbuf.data(), 1024)) > 0) {
            c->q.insert(c->q.end(), c->rbuf.begin(), c->rbuf.begin() + (size_t)got * ch);
        }
        size_t have = c->q.size() / ch;
        if (!c->primed && have >= c->prime + n) c->primed = true;
        size_t take = 0;
        if (c->primed) {
            take = std::min(have, n);
            if (take < n) {
                c->primed = false;
            }
        }
        size_t pad = n - take;
        memset(tout, 0, pad * ch * sizeof(float));
        if (take) {
            memcpy(tout + pad * ch, c->q.data(), take * ch * sizeof(float));
            c->q.erase(c->q.begin(), c->q.begin() + take * ch);
        }
        size_t left = c->q.size() / ch;
        size_t maxq = c->prime * 3 + n;
        if (c->primed && left > maxq) {
            c->q.erase(c->q.begin(), c->q.begin() + (left - c->prime) * ch);
        }
    }

    if (c->fmt == FMT_FLOAT) {
        if (acc) for (size_t i = 0; i < ns; i++) out->f32[i] += tout[i];
        else memcpy(out->f32, tout, ns * sizeof(float));
    } else {
        for (size_t i = 0; i < ns; i++) {
            float v = tout[i] * 32768.0f;
            if (acc) v += out->s16[i];
            if (v > 32767.f) v = 32767.f;
            if (v < -32768.f) v = -32768.f;
            out->s16[i] = (int16_t)v;
        }
    }
    return 0;
}

static int32_t fx_command(effect_handle_t self, uint32_t cmd, uint32_t cmdSize, void* pCmd,
                          uint32_t* replySize, void* pReply) {
    Ctx* c = (Ctx*)self;
    if (!c) return -EINVAL;
    const bool hasReply = pReply && replySize && *replySize >= sizeof(int32_t);
    switch (cmd) {
        case CMD_INIT:
            if (!hasReply) return -EINVAL;
            *(int32_t*)pReply = 0;
            return 0;
        case CMD_SET_CONFIG:
        case CMD_SET_CONFIG_REVERSE: {
            if (!pCmd || cmdSize < sizeof(effect_config_t) || !hasReply) return -EINVAL;
            if (cmd == CMD_SET_CONFIG_REVERSE) {
                *(int32_t*)pReply = 0;
                return 0;
            }
            const effect_config_t* ec = (const effect_config_t*)pCmd;
            int32_t r = setConfig(c, ec);
            *(int32_t*)pReply = r;
            return 0;
        }
        case CMD_GET_CONFIG:
            if (!pReply || !replySize || *replySize < sizeof(effect_config_t) || !c->configured)
                return -EINVAL;
            memcpy(pReply, &c->cfg, sizeof(effect_config_t));
            return 0;
        case CMD_GET_CONFIG_REVERSE:
            return -EINVAL;
        case CMD_RESET:
            if (c->configured) resetCtx(c);
            return 0;
        case CMD_ENABLE:
            if (!hasReply) return -EINVAL;
            if (!c->configured) {
                *(int32_t*)pReply = -EINVAL;
                return 0;
            }
            c->enabled = true;
            resetCtx(c);
            *(int32_t*)pReply = 0;
            return 0;
        case CMD_DISABLE:
            if (!hasReply) return -EINVAL;
            c->enabled = false;
            if (c->configured) resetCtx(c);
            *(int32_t*)pReply = 0;
            return 0;
        case CMD_SET_DEVICE:
        case CMD_SET_VOLUME:
        case CMD_SET_AUDIO_MODE:
        case CMD_SET_INPUT_DEVICE:
        case CMD_SET_AUDIO_SOURCE:
            if (hasReply) *(int32_t*)pReply = 0;
            return 0;
        default:
            return -EINVAL;
    }
}

static int32_t fx_get_descriptor(effect_handle_t self, effect_descriptor_t* d) {
    if (!self || !d) return -EINVAL;
    fillDescriptor(d);
    return 0;
}

static int32_t fx_process_reverse(effect_handle_t, audio_buffer_t*, audio_buffer_t*) {
    return -ENODATA;
}

static effect_interface_s g_itfe = {fx_process, fx_command, fx_get_descriptor, fx_process_reverse};

static bool sameUuid(const effect_uuid_t* a, const effect_uuid_t* b) {
    return memcmp(a, b, sizeof(effect_uuid_t)) == 0;
}

static int32_t lib_create(const effect_uuid_t* uuid, int32_t sessionId, int32_t ioId,
                          effect_handle_t* pHandle) {
    if (!uuid || !pHandle) return -EINVAL;
    if (!sameUuid(uuid, &FX_UUID)) {
        return -ENOENT;
    }
    Ctx* c = new (std::nothrow) Ctx();
    if (!c) return -ENOMEM;
    c->itfe = &g_itfe;
    memset(&c->cfg, 0, sizeof(c->cfg));
    c->st = new (std::nothrow) soundtouch::SoundTouch();
    if (!c->st) {
        delete c;
        return -ENOMEM;
    }
    c->configured = c->enabled = c->primed = false;
    c->ch = 2;
    c->fmt = FMT_FLOAT;
    c->sr = 48000;
    c->prime = 1920;
    *pHandle = (effect_handle_t)c;
    return 0;
}

static int32_t lib_release(effect_handle_t h) {
    Ctx* c = (Ctx*)h;
    if (!c) return -EINVAL;
    delete c->st;
    delete c;
    return 0;
}

static int32_t lib_get_descriptor(const effect_uuid_t* uuid, effect_descriptor_t* d) {
    if (!uuid || !d) return -EINVAL;
    bool match = sameUuid(uuid, &FX_UUID);
    if (!match) return -ENOENT;
    fillDescriptor(d);
    return 0;
}

extern "C" {
__attribute__((visibility("default"))) audio_effect_library_t AELI = {
    LIB_TAG, LIB_VERSION, "Pitch432 library", "Jamagoze", lib_create, lib_release,
    lib_get_descriptor};
}
