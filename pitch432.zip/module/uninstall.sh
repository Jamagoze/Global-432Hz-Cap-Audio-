#!/system/bin/sh
rm -rf /data/pitch432
