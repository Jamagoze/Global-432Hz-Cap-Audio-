#!/system/bin/sh
MODDIR=${0%/*}
mkdir -p /data/pitch432
cp -f $MODDIR/config.txt /data/pitch432/config.txt
. $MODDIR/apply.sh
