#!/system/bin/sh
MODDIR=${0%/*}
D=/data/pitch432
mkdir -p $D
cp -f $MODDIR/config.txt $D/config.txt
chmod 0777 $D
chmod 0666 $D/config.txt
[ -f $D/pitch432.log ] && chmod 0666 $D/pitch432.log
chcon -R u:object_r:pitch432_data:s0 $D 2>/dev/null
