UUID="7c1d9e52-30ab-4f68-b2e4-5a96c0d83f17"
ui_print "- Pitch 432Hz"

patch_xml() {
  src="$1"; dst="$2"
  [ -f "$src" ] || return 0
  mkdir -p "$(dirname "$dst")"
  cp -f "$src" "$dst"
  if grep -q 'libpitch432' "$dst"; then return 0; fi
  sed -i "/<libraries>/a\\    <library name=\"pitch432\" path=\"libpitch432.so\"/>" "$dst"
  sed -i "/<effects>/a\\    <effect name=\"pitch432\" library=\"pitch432\" uuid=\"$UUID\"/>" "$dst"
  ui_print "- patched $src"
}

patch_xml /system/etc/audio_effects.xml "$MODPATH/system/etc/audio_effects.xml"
patch_xml /vendor/etc/audio_effects.xml "$MODPATH/system/vendor/etc/audio_effects.xml"
patch_xml /vendor/etc/audio/audio_effects.xml "$MODPATH/system/vendor/etc/audio/audio_effects.xml"

set_perm_recursive "$MODPATH/system" 0 0 0755 0644
set_perm_recursive "$MODPATH/system/priv-app" 0 0 0755 0644 u:object_r:system_file:s0
set_perm_recursive "$MODPATH/system/lib64/soundfx" 0 0 0755 0644 u:object_r:system_lib_file:s0
set_perm_recursive "$MODPATH/system/lib/soundfx" 0 0 0755 0644 u:object_r:system_lib_file:s0
[ -d "$MODPATH/system/vendor/lib64/soundfx" ] && set_perm_recursive "$MODPATH/system/vendor/lib64/soundfx" 0 0 0755 0644 u:object_r:vendor_file:s0
[ -d "$MODPATH/system/vendor/lib/soundfx" ] && set_perm_recursive "$MODPATH/system/vendor/lib/soundfx" 0 0 0755 0644 u:object_r:vendor_file:s0
[ -d "$MODPATH/system/vendor/etc" ] && set_perm_recursive "$MODPATH/system/vendor/etc" 0 0 0755 0644 u:object_r:vendor_configs_file:s0
