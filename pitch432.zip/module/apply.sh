#!/system/bin/sh
# Applies the SELinux rules for /data/pitch432 live and labels the folder. Safe to run repeatedly.
D=/data/pitch432
BL=/data/local/tmp/pitch432_boot.log
MP=$(command -v magiskpolicy 2>/dev/null)
[ -z "$MP" ] && [ -x /data/adb/magisk/magiskpolicy ] && MP=/data/adb/magisk/magiskpolicy
{
  echo "== $(date) magiskpolicy=$MP"
  stmt() {
    if [ -n "$MP" ]; then
      out=$($MP --live "$1" 2>&1); rc=$?
      echo "rc=$rc : $1 $out"
    else
      echo "no magiskpolicy: $1"
    fi
  }
  stmt "type pitch432_data file_type data_file_type"
  stmt "typeattribute pitch432_data mlstrustedobject"
  for d in hal_audio_default audioserver priv_app system_app; do
    stmt "allow $d pitch432_data dir { search getattr open read write add_name remove_name create setattr }"
    stmt "allow $d pitch432_data file { create open read write append getattr setattr unlink rename lock map }"
  done
  mkdir -p $D
  chmod 0777 $D
  chmod 0666 $D/config.txt 2>/dev/null
  [ -f $D/pitch432.log ] && chmod 0666 $D/pitch432.log
  chcon -R u:object_r:pitch432_data:s0 $D; echo "chcon rc=$?"
  ls -ldZ $D
} >> $BL 2>&1
