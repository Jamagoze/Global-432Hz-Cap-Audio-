#!/system/bin/sh
# Applies the SELinux rules for /data/pitch432 live and labels the folder. Safe to run repeatedly.
D=/data/pitch432
BL=/data/local/tmp/pitch432_boot.log
MP=$(command -v magiskpolicy 2>/dev/null)
[ -z "$MP" ] && [ -x /data/adb/magisk/magiskpolicy ] && MP=/data/adb/magisk/magiskpolicy
[ -f $BL ] && [ "$(wc -c < $BL)" -gt 100000 ] && : > $BL
{
  echo "== $(date) magiskpolicy=$MP"
  try() {
    out=$($MP --live "$1" 2>&1)
    echo "$1 => ${out:-ok}"
    echo "$out" | grep -qiE "syntax error|does not exist|error" && return 1
    return 0
  }
  if [ -n "$MP" ]; then
    try "type pitch432_data file_type" || try "type pitch432_data { file_type }" || try "type pitch432_data"
    try "typeattribute pitch432_data data_file_type" || try "typeattribute pitch432_data { data_file_type }"
    try "typeattribute pitch432_data mlstrustedobject" || try "typeattribute pitch432_data { mlstrustedobject }"
    if try "typeattribute pitch432_data file_type"; then
      for d in hal_audio_default audioserver priv_app system_app; do
        try "allow $d pitch432_data dir { search getattr open read write add_name remove_name create setattr }"
        try "allow $d pitch432_data file { create open read write append getattr setattr unlink rename lock map }"
      done
    else
      echo "type pitch432_data missing, skipped allow rules"
    fi
  else
    echo "no magiskpolicy found"
  fi
  mkdir -p $D
  chmod 0777 $D
  chmod 0666 $D/config.txt 2>/dev/null
  [ -f $D/pitch432.log ] && chmod 0666 $D/pitch432.log
  chcon -R u:object_r:pitch432_data:s0 $D; echo "chcon rc=$?"
  ls -ldZ $D
} >> $BL 2>&1
